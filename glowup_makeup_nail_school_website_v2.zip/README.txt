GLOWUP MAKEUP & NAIL SCHOOL WEBSITE

Files:
- index.html: complete responsive website (no paid software or external libraries required)

Preview:
Open index.html in a web browser.

Publish for free with GitHub Pages:
1. Sign in at https://github.com and create a public repository, e.g. glowup-school.
2. Upload index.html to the repository root.
3. Open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch, branch main, folder /(root), then Save.
5. After publishing, GitHub will show your site address, usually https://YOUR-USERNAME.github.io/glowup-school/

Custom domain:
A domain such as glowupmakeupnailschool.com usually costs money to register. GitHub Pages hosting can be free, but a custom domain is generally not free. After purchasing a domain, configure it under Settings > Pages > Custom domain and add the DNS records GitHub specifies.

The supplied email address is included exactly as provided (5glowupschhol@gmail.com). The second phone number was removed as requested. Vision, mission, and core values were added in Amharic.


LATEST UPDATE:
- Makeup fee changed to 6,000 ETB.
- Added payment methods: CBE 10000, Telebirr 0920353893, Awash Bank 01320.
- Added enrollment form for student/recipient name, phone, course, first class date (Monday validation), preferred shift, payment method, and optional receipt file picker.
- The form opens WhatsApp with enrollment details. Uploaded receipt files are not sent automatically; for receipt handling, use a secure form backend or ask students to send receipts directly via WhatsApp.
- Shift times are shown as supplied; confirm the intended clock system and exact time formatting before publishing.
